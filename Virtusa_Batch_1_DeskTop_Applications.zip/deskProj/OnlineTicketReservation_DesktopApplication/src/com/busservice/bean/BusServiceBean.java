package com.busservice.bean;

public class BusServiceBean {
	
	private long serviceNumber;
	private String source;
	private String destination;
	private int seatsCapacity;

	
	public BusServiceBean(long serviceNumber,String source,String destination,int seatsCapacity)
	{
		this.serviceNumber=serviceNumber;
		this.source=source;
		this.destination=destination;
		this.seatsCapacity=seatsCapacity;
	}
	
	
	public long getServiceNumber() {
		return serviceNumber;
	}

	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getSeatsCapacity() {
		return seatsCapacity;
	}
	public void setSeatsCapacity(int seatsCapacity) {
		this.seatsCapacity = seatsCapacity;
	}
	

}
