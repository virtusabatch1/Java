package com.ticketreservationsystem.service;
import com.ticketreservation.bean.PassengerBean;
import com.ticketreservation.main.MainClass;
import com.busservice.bean.BusServiceBean;

import java.util.*;

public class TicketReservation
{

	private List<PassengerBean> ticketList = new ArrayList<>();
	
	private List<BusServiceBean> serviceList=new ArrayList<>();
	Scanner scan = new Scanner(System.in);
	
	
	//Admin Login
	public boolean adminLogin(String adminName,String password)
	{
		String username="admin";
		String pwd="admin@123";
		
		if(adminName.equals(username)&& password.equals(pwd) )
		{
			System.out.println("Successful Login") ;
			return true;
		}
		
		return false;
	}
	
	//Add New Bus Service
	public boolean addService(BusServiceBean bsb)
	{
		boolean a=serviceList.add(bsb);
		System.out.println("Service has been successfully added");
		return a;
	}

	
	//Generate Service Number
	public long generateServiceNumber()
	{
		long lowerLimit=1111;
		long upperLimit=9999;
		long serviceNumber= lowerLimit+(long)(Math.random()*(upperLimit-lowerLimit));
		return serviceNumber;
	}


	//Display All The Services
	public List<BusServiceBean> fetchAllServices()
	{
		System.out.println("Retrieving Bus Services Details");
		
		Iterator<BusServiceBean> itr=serviceList.iterator();
		
		
		while(itr.hasNext()) 
		{
			BusServiceBean bsb=itr.next();
			
			
				System.out.println(bsb.getServiceNumber());
				System.out.println(bsb.getSource());
				System.out.println(bsb.getDestination());
				System.out.println(bsb.getSeatsCapacity());
		}
		
		return serviceList;
	}
	
	//Modify Bus Service Details Based on Service Number
	public boolean updateBusServiceByNumber(long serviceNumber) {
		
		for(BusServiceBean bsb :serviceList) {
			if(bsb.getServiceNumber()==serviceNumber) 
			{
				System.out.println("Enter new place of origin");
				bsb.setSource(scan.next());
				System.out.println("Enter new destination:");
				bsb.setDestination(scan.next());
				System.out.println("Enter seat capacity");
				bsb.setSeatsCapacity(scan.nextInt());
				return true;
			}
			
		}
		return false;
	}	
	
	
	//Remove A Bus Service Based On Service Number
	public boolean removeService(long serviceNumber)
	{
		for(BusServiceBean bsb:serviceList)
		{
			if(bsb.getServiceNumber()==serviceNumber)
			{
				
				serviceList.remove(bsb);
				return true;
				
			}
		}
		return false;
	
	}
	
	
	//Display List Of Services Available For a Particular User Desired Route
/*	public List<BusServiceBean>  fetchDesiredServices(String source,String destination)
	{
		System.out.println("Retrieving User Desired Service Details");
		
		Iterator<BusServiceBean> itr=serviceList.iterator();
		
		
		while(itr.hasNext()) 
		{
			BusServiceBean bsb=itr.next();
			if((bsb.getSource()==source) && (bsb.getDestination()==destination))
			{
				System.out.println(bsb.getServiceNumber()+"  "+bsb.getSource()+"  "+bsb.getDestination());
				System.out.println();
			}
		}
		
		return serviceList;
	}
	
	*/
	
	
	//Book Ticket For Journey
		public boolean bookTicket(PassengerBean passenger)
		{
			boolean b=ticketList.add(passenger);
			System.out.println("Ticket has been successfully booked");
			return b;
		}
	
	
	//Generating Ticket Number Upon Booking
	public long generateTicketNumber()
	{
		long lowerLimit=10000;
		long upperLimit=99999;
		long ticketNumber= lowerLimit+(long)(Math.random()*(upperLimit-lowerLimit));
		return ticketNumber;
	}
	
	//Display Passenger List
	public List<PassengerBean> fetchAllPassengers()
	{
		System.out.println("Retrieving Passenger Details");
		
		Iterator<PassengerBean> itr=ticketList.iterator();
		
		
		while(itr.hasNext()) 
		{
			PassengerBean pb=itr.next();
			
			
				System.out.println(pb.getName());
				System.out.println(pb.getAge());
				System.out.println(pb.getGender());
				System.out.println(pb.getEmail());
				System.out.println(pb.getPhoneNumber());
				System.out.println(pb.getTicketNumber());
			
		}
		
		return ticketList;
	}

	
	public boolean retrieveTicketByTicketNumber(long ticketNumber) {
		
		for(PassengerBean pb :ticketList) {
			if(pb.getTicketNumber()==ticketNumber) 
			{
				System.out.println("Ticket Number:  "+pb.getTicketNumber());
				System.out.println("Name:  "+pb.getName());
				System.out.println("Age:  "+pb.getAge());
				System.out.println("Gender:  "+pb.getGender());
				System.out.println("Phone:  "+pb.getPhoneNumber());
				System.out.println("Email:  "+pb.getEmail());
				
				return true;
			}
			
		}
		return false;
	}
	
	//Cancel Ticket
	public boolean cancelTicket(long ticketNumber)
	{
		for(PassengerBean pb:ticketList)
		{
			if(pb.getTicketNumber()==ticketNumber)
			{
				
				ticketList.remove(pb);
				return true;
				
			}
		}
		return false;
	
	}

}
