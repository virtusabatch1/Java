package com.ticketreservation.main;
import com.ticketreservation.bean.PassengerBean;
import com.ticketreservationsystem.service.TicketReservation;
import com.busservice.bean.BusServiceBean;
import com.ticketreservation.bean.AdminBean;

import java.util.Iterator;
import java.util.Scanner;


public class MainClass
{

	public static void main(String[] args) 
	{
		
		Scanner sc=new Scanner(System.in); 
		
		TicketReservation tr1=new TicketReservation();
		
		System.out.println("Choose an option");
		System.out.println("1.ADMIN");
		System.out.println("2.USER");
		
		int choice=sc.nextInt();
		
		int option;
				if(choice==1)
				{
						System.out.println("admin username");
						String username=sc.next();
						
						System.out.println("adminpassword");
						String password=sc.next();
						boolean b=tr1.adminLogin(username, password);
						
					if(b==true)
					{
						while(true)
						{
							System.out.println("MENU");
							System.out.println("1:Add Bus Service");
							System.out.println("2:Retrieve Service Details");
							System.out.println("3:Remove Bus Service");
							System.out.println("4:Modify Bus Service");
							System.out.println("5:Book Ticket");
							System.out.println("6:Retrieve Passenger Details");
							System.out.println("7:Retrieve Ticket Details By Ticket Number");
							System.out.println("8:Cancel Tciket");
							System.out.println("9:Exit");
						
							System.out.println("Choose required option");
							option=sc.nextInt();
						
					
						switch(option)
						{
							case 1:	
								System.out.println("Enter place of origin");
								String source=sc.next();
							
								System.out.println("Enter destination");
								String destination=sc.next();
							
								System.out.println("Enter total seat capacity");
								int seatCapacity=sc.nextInt();
							
								long serviceNumber=tr1.generateServiceNumber();
							
								BusServiceBean bsb=new BusServiceBean(serviceNumber,source,destination,seatCapacity);
							
								tr1.addService(bsb);
							
								System.out.println();
								break;
							
						case 2: System.out.println(tr1.fetchAllServices());
								break;
								
						case 4: System.out.println("Enter service Number to Modify details");
								serviceNumber=sc.nextLong();
								tr1.updateBusServiceByNumber(serviceNumber);
								break;
							
						case 3:	System.out.println("Enter Service number to cancel the service");
								if(tr1.removeService(sc.nextInt()))
								{
									System.out.println("Service Cancelled");
									System.out.println();
								}
								break;
						
						case 5:	System.out.println("Enter name");
								String name=sc.next();

					
								System.out.println("Enter age");
								int age=sc.nextInt();
					
								System.out.println("Enter phone number");
								String phNo=sc.next();
					
								System.out.println("Enter gender");
								String gender=sc.next();
					
								System.out.println("Enter mail id");
								String email=sc.next();
							
								System.out.println();
							
								long ticketNumber=tr1.generateTicketNumber();
							
								PassengerBean pb=new PassengerBean(name,age,phNo,gender,email,ticketNumber);
							
								tr1.bookTicket(pb);
							
								System.out.println();
								break;
				
						case 6: System.out.println(tr1.fetchAllPassengers());
								break;
								
						case 7: System.out.println("Enter Ticket Number");
								ticketNumber=sc.nextLong();
						
								tr1.retrieveTicketByTicketNumber(ticketNumber);
								break;
				
						case 8:	System.out.println("Enter Ticket Number To Cancel Ticket");
								if(tr1.cancelTicket(sc.nextInt()))
								{
									System.out.println("Ticket Cancelled");
									System.out.println();
								}
								break;
						
						case 9: System.exit(0);
				
						default:System.out.println("No Option Choosen");
					}
					}
				}
					else
						System.out.println("Unsuccessful login");
				}
				
				else if(choice==2)
				{
					while(true)
					{
						System.out.println("1:Book Ticket");
						System.out.println("2:Retrieve Passenger Details");
						System.out.println("3:Retrieve Ticket Details By Number");
						System.out.println("4:Cancel Tciket");
						System.out.println("5:Exit");
					
					System.out.println("Choose required option");
					option=sc.nextInt();
					
				
					switch(option)
					{
					
						case 1: System.out.println("Enter name");
								String name=sc.next();

	
								System.out.println("Enter age");
								int age=sc.nextInt();
	
								System.out.println("Enter phone number");
								String phNo=sc.next();
	
								System.out.println("Enter gender");
								String gender=sc.next();
	
								System.out.println("Enter mail id");
								String email=sc.next();
			
								System.out.println();
			
								long ticketNumber=tr1.generateTicketNumber();
			
								PassengerBean b=new PassengerBean(name,age,phNo,gender,email,ticketNumber);
			
								tr1.bookTicket(b);
			
								System.out.println();
								break;

						case 2: System.out.println(tr1.fetchAllPassengers());
								break;
								
						case 3: System.out.println("Enter Ticket Number");
								ticketNumber=sc.nextLong();
								
								tr1.retrieveTicketByTicketNumber(ticketNumber);

						case 4:	System.out.println("Enter Ticket Number To Cancel Ticket");
								if(tr1.cancelTicket(sc.nextInt()))
								{
									System.out.println("Ticket Cancelled");
									System.out.println();
								}
								break;
		
						case 5: System.exit(0);

						default:System.out.println("No Option Choosen");
					}
				}
			}

	}
}
