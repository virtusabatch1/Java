package com.ticketreservation.bean;
import java.util.*;

public class PassengerBean {	
	
	private String name;
	private int age;
	private String phoneNumber;
	private String gender; 
	private String email;
	private long ticketNumber;
	
	
	public PassengerBean(String name,int age,String phoneNumber,String gender,String email,long ticketNumber)
	{
		this.name=name;
		this.age=age;
		this.phoneNumber=phoneNumber;
		this.gender=gender;
		this.email=email;
		this.ticketNumber=ticketNumber;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}	
	
	public long getTicketNumber()
	{
		return ticketNumber;
	}
	
	
}
