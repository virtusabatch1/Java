package com.vforum.model;

public class Posts 
{
	private int postId;
	private String subject;
	private String postContent;
	private int empid;
	
	public Posts(int postId, String subject, String postContent, int empid)
	{
		this.postId = postId;
		this.subject = subject;
		this.postContent = postContent;
		this.empid = empid;
	}

	public int getPostId() {
		return postId;
	}

	public void setPostId(int postId) {
		this.postId = postId;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getPostContent() {
		return postContent;
	}

	public void setPostContent(String postContent) {
		this.postContent = postContent;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}
	
	
}
