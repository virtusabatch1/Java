package com.vforum.model;

public class Answers 
{
	private int ansid;
	private String answer_content;
	private int empid;
	private int postid;
	
	public Answers(int ansid, String answer_content, int empid, int postid)
	{
		this.ansid = ansid;
		this.answer_content = answer_content;
		this.empid = empid;
		this.postid = postid;
	}
	
	public int getPostid() {
		return postid;
	}

	public void setPostid(int postid) {
		this.postid = postid;
	}

	public int getAnsid() {
		return ansid;
	}
	public void setAnsid(int ansid) {
		this.ansid = ansid;
	}
	public String getAnswer_content() {
		return answer_content;
	}
	public void setAnswer_content(String answer_content) {
		this.answer_content = answer_content;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
}
