package com.vforum.model;

import java.util.ArrayList;
import java.util.HashMap;

public class Employee 
{
	private String name;
	private String email;
	private String password;
	private int empid;
	
	public HashMap map = new HashMap(); 
	public Employee(String name, String email, int empid, String password)
	{
		
		 map.put("Name", this.name = name); 
	     map.put("Email", this.email = email); 
	     map.put("EmpId", this.empid = empid);
	     map.put("Password", this.password = password); 
	}

	public Employee(ArrayList arr) {
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public HashMap getMap() {
		return map;
	}

	public void setMap(HashMap map) {
		this.map = map;
	}
}
