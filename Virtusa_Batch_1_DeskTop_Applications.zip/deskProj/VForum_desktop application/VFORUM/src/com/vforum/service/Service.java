
package com.vforum.service;

import com.vforum.dao.VForumDao;
import com.vforum.model.Answers;
import com.vforum.model.Employee;
import com.vforum.model.Posts;

public class    Service                                                                                            
{	
	VForumDao forumdao = new VForumDao();
	
	public void registerEmployee()
	{
		forumdao.registerEmployee();
	}
	
	public Employee loginEmployee()
	{
		return forumdao.loginEmployee();
	}
	
	public void viewPosts()
	{
		forumdao.viewPosts();
	}

	public void addPost(Employee eobj) 
	{
		forumdao.addPost(eobj);
	}
	
	public void addAnswer(Employee e) 
	{
		forumdao.addAnswer(e);
	}
	
	public void logout() {
		// TODO Auto-generated method stub
		
	}

	
}
