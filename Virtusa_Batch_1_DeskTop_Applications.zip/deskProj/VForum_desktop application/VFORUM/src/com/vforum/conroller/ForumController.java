package com.vforum.conroller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

import com.vforum.model.Employee;
import com.vforum.model.Posts;
import com.vforum.service.Service;

class ForumController
{
	public static void main(String args[])
	{
		
		ForumController t = new ForumController();
		t.mainSrvice();
	}
	public void mainSrvice()
	{
		Service service = new Service();
		ArrayList arr = new ArrayList();
		ForumController t = new ForumController();
		Scanner sc = new Scanner(System.in);
		System.out.println("\t\t\t WELCOME TO VFORUM");
		
		while(true)
		{
			System.out.println("Enter your Option");
			System.out.println("1.Register User 2. Login");
			
			int ch = sc.nextInt();
			
			if(ch== 1)
			{
				service.registerEmployee();
				continue;
			}
		
			if(ch == 2)
			{
				break;

			}
			
		}
		t.loginServices();
	}	

	public void loginServices() 
	{
		Service service = new Service();
		ForumController t = new ForumController();
		
		Employee result = service.loginEmployee();
		
		if(result != null)
		{
			System.out.println("Login Successful");
			t.otherServices(result);
			
		}	
		
	}

	private void otherServices(Employee e) 
	{
		Service service = new Service();
		ForumController t = new ForumController();
		Scanner sc = new Scanner(System.in);
		System.out.println("Please Select the options");

		System.out.println("1.View Posts 2. Ask a Question 3. Answer a question 4.Logout");
		
		int ch = sc.nextInt();
		
		if(ch == 1)
		{
			service.viewPosts();
			t.otherServices(e);
		}
		else if(ch == 2)
		{
			service.addPost(e);
			t.otherServices(e);
		}
		
		else if(ch == 3)
		{
			service.addAnswer(e);
			t.otherServices(e);
		}
		
		else if(ch ==4)
		{
			service.logout();
			t.mainSrvice();
			
		}
		
	}
}
