package com.vforum.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.vforum.model.Answers;
import com.vforum.model.Employee;
import com.vforum.model.Posts;

public class VForumDao {

	static ArrayList<Employee> empList = new ArrayList<>();
	static ArrayList<Posts> postList = new ArrayList<>();
	static ArrayList<Answers> answerList = new ArrayList<>();
	
	
	Employee currentEmp = null;
	Posts currentPost = null;
	Employee currentEmployee = null;
	Answers currentAnswer = null;
	
	Scanner sc = new Scanner(System.in);
	
	public void registerEmployee()
	{
		
		System.out.println("enter employee name");
		String name = sc.next();
		
		
		System.out.println("enter employee email");
		String email = sc.next();
		
		
		System.out.println("enter employee ID");
		int empid = sc.nextInt();
		sc.nextLine();
		
		System.out.println("enter employee password");
		String password = sc.next();
		
		
		boolean check = empList.add(new Employee(name,email,empid,password));
		if(check == true)
			System.out.println("Employee registered succesfully");
		else
			System.out.println("Employee not registered");
		
	}
	
	public Employee loginEmployee()
	{
		int flag = 0;
		System.out.println("enter employee ID");
		int empid = sc.nextInt();
		System.out.println("enter employee password");
		String pass = sc.nextLine();
		sc.next();
		
		Iterator<Employee> iterator = empList.iterator();
		while(iterator.hasNext())
		{
			
			currentEmp = iterator.next();
			System.out.println(currentEmp.getEmpid() + currentEmp.getPassword());
			if(currentEmp.getEmpid() == empid)
			{
				flag = 1;
				currentEmployee = currentEmp;
				break;
				
			}
		}
		if(flag == 1)
			return currentEmployee;
		
		return null;
	}
	
	public void viewPosts()
	{
		ArrayList<Answers> ansList = new ArrayList<>();
		
		Iterator<Posts> iterator = postList.iterator();
		Posts currentpost = null;
		Answers currentans = null;
		while(iterator.hasNext())
		{
			currentpost = iterator.next();
			System.out.println("Post Id : " + currentpost.getPostId() + " Post Subject is : " + currentpost.getSubject() + " Post Content is : " + currentpost.getPostContent() + " Posted By : " + currentpost.getEmpid());
			System.out.println();
			System.out.println("Replies are :");
			
			ansList = VForumDao.getAnswers(currentpost.getPostId());
			Iterator<Answers> ansItr = ansList.iterator();
			while(ansItr.hasNext())
			{
				currentans = ansItr.next();
				System.out.println("Answer Id is : " + currentans.getAnsid() + "		Answer content is : " + currentans.getAnswer_content() + " 		Answered By : " + currentans.getEmpid());
			}
			System.out.println();
			
		}
		
	}

	public void addPost(Employee eobj) 
	{
		System.out.println("enter post subject");
		String subject = sc.nextLine();
		
		
		System.out.println("enter post content or question in detail");
		String content = sc.nextLine();
		
		System.out.println("enter post ID");
		int postid = sc.nextInt();

		boolean check = postList.add(new Posts(postid,subject,content,eobj.getEmpid()));
		if(check)
			System.out.println("Post added successfully");
		else
			System.out.println("Post addeding failed");
		
	}
	
	public void addAnswer(Employee e) 
	{
		System.out.println("enter your answer");
		String answer_content = sc.nextLine();
		
		System.out.println("enter answer ID");
		int ansid = sc.nextInt();
		
		System.out.println("enter post ID");
		int postid = sc.nextInt();
		
		
		
		boolean check = answerList.add(new Answers(ansid, answer_content, e.getEmpid(), postid));
		if(check)
			System.out.println("Answered added successfully");
		else
			System.out.println("Answering failed");
		
	}
	
	private static ArrayList<Answers> getAnswers(int postId) 
	{
		ArrayList<Answers> ansList = new ArrayList<>();
		Iterator<Answers> iterator = answerList.iterator();
		Answers currentAns = null;
		while(iterator.hasNext())
		{	
			currentAns = iterator.next();
			
			if(currentAns.getPostid() == postId)
			{
				ansList.add(currentAns);
			}		
		}
		return ansList;
	}
}
