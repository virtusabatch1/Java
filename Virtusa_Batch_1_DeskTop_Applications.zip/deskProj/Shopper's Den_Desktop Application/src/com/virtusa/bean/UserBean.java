package com.virtusa.bean;

public class UserBean {
	   int Userid;
	   String passsword;
	   String name;
	   long phonenumb;
	
	public UserBean(int userid, String passsword, String name, long phonenumb) {
		super();
		Userid = userid;
		this.passsword = passsword;
		this.name = name;
		this.phonenumb = phonenumb;
	}
	public int getUserid() {
		return Userid;
	}
	public void setUserid(int userid) {
		Userid = userid;
	}
	public String getPasssword() {
		return passsword;
	}
	public void setPasssword(String passsword) {
		this.passsword = passsword;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPhonenumb() {
		return phonenumb;
	}
	public void setPhonenumb(long phonenumb) {
		this.phonenumb = phonenumb;
	}
	   
	   
	public String toString() {
		return Userid+" "+name+" "+passsword+" "+phonenumb;
	}

}
