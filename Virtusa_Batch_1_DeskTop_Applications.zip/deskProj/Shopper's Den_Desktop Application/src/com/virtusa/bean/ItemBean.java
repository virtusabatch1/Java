package com.virtusa.bean;

public class ItemBean {
	int Item_id;
	String Item_name;
	double Item_cost;
	
	public ItemBean(int item_id, String item_name, double item_cost) {
		super();
		Item_id = item_id;
		Item_name = item_name;
		Item_cost = item_cost;
	}
	
	public int getItem_id() {
		return Item_id;
	}
	public void setItem_id(int item_id) {
		Item_id = item_id;
	}
	public String getItem_name() {
		return Item_name;
	}
	public void setItem_name(String item_name) {
		Item_name = item_name;
	}
	public double getItem_cost() {
		return Item_cost;
	}
	public void setItem_cost(double item_cost) {
		Item_cost = item_cost;
	}
	
	@Override
	public String toString() {
		return "ItemBean [Item_id=" + Item_id + ", Item_name=" + Item_name + ", Item_cost=" + Item_cost + "]";
	}
	
	
}