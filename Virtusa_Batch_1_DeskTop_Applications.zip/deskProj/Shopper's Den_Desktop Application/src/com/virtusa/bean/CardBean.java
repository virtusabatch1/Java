package com.virtusa.bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CardBean {

	double card_no;
	String date_of_issue;
	double UserId;
	String expiry_date;
	public CardBean(double card_no2, String date_of_issue, String expiry_date, double user_id) {
		// TODO Auto-generated constructor stub
		super();
		this.card_no=card_no2;
		this.date_of_issue=date_of_issue;
		this.expiry_date=expiry_date;
		this.UserId=user_id;
		
	}
	public double getCard_no() {
		return card_no;
	}
	public void setCard_no(double card_no) {
		this.card_no = card_no;
	}
	public String getDate_of_issue() {
		return date_of_issue;
	}
	public void setDate_of_issue(String date_of_issue) {
		this.date_of_issue = date_of_issue;
	}
	public double getUserId() {
		return UserId;
	}
	public void setUserId(int userId) {
		UserId = userId;
	}
	public String getExpiry_date() {
		return expiry_date;
	}
	@Override
	public String toString() {
		return "CardDetails [card_no=" + card_no + ", date_of_issue=" + date_of_issue + ", UserId=" + UserId
				+ ", expiry_date=" + expiry_date + "]";
	}
	public void setExpiry_date(String expiry_date) {
		this.expiry_date = expiry_date;
	}
	
	}