package com.virtusa.bean;

public class OrderBean {
	int order_id;
	String status;
	String user_address;
	public OrderBean(int order_id2, String status2, String user_address2) {
		// TODO Auto-generated constructor stub
		super();
		this.order_id = order_id2;	
		this.status = status2;
		this.user_address = user_address2;
	}
	
	public int getOrder_id() {
		return order_id;
	}
	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getUser_address() {
		return user_address;
	}
	public void setUser_address(String user_address) {
		this.user_address = user_address;
	}
	@Override
	public String toString() {
		return "OrderBean [order_id=" + order_id + ", status=" + status + ", user_address="
				+ user_address + "]";
	}
}
