package com.virtusa.bean;

public class AdminBean {
	int adminid;
	String password;
	String name;
	long phonenumb;
	

	public AdminBean(int adminid, String password, String name, long phonenumb) {
		super();
		this.adminid = adminid;
		this.password = password;
		this.name = name;
		this.phonenumb = phonenumb;
	}
	
	public int getAdminid() {
		return adminid;
	}
	public void setAdminid(int adminid) {
		this.adminid = adminid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPhonenumb() {
		return phonenumb;
	}
	public void setPhonenumb(long phonenumb) {
		this.phonenumb = phonenumb;
	}
	@Override
	public String toString() {
		return "AdminBean [adminid=" + adminid + ", password=" + password + ", name=" + name + ", phonenumb="
				+ phonenumb + "]";
	}

}
