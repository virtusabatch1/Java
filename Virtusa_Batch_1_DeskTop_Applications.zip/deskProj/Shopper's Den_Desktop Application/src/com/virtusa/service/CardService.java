package com.virtusa.service;

import java.util.ArrayList;

import com.virtusa.bean.CardBean;

public class CardService {
	 ArrayList<CardBean> card=new ArrayList<CardBean>();
	
	 public  String card_data(double card_no2, String date_of_issue2, String date_of_expiry, double user_id)   {
		   if(card.add(new CardBean(card_no2,date_of_issue2,date_of_expiry,user_id))) {
		 return "user Card details added succesfully:";}
		 else {
		    return "card details Not added: ";
		   
		    }
		   }

}
