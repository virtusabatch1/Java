package com.virtusa.service;

import java.util.ArrayList;

import com.virtusa.bean.AdminBean;

import com.virtusa.bean.CategoryBean;

public class AdminService {
	ArrayList<AdminBean> admin=new ArrayList<AdminBean>();
	ArrayList<CategoryBean> category=new ArrayList<CategoryBean>();
	public boolean adminLogin(int Adminid,String password) {
		   boolean  res = false;
		   
		   for(int i=0;i<admin.size();i++) {
			   
			   AdminBean ab =admin.get(i);
			   if(ab.getAdminid()==(Adminid)&&ab.getPassword().equals(password)){
				   res = true;
			   }
		   }
		   
		   return res;

	   }
	public String adminregistration(int adminid, String password, String name, long phonenumber) {
		
		if(admin.add(new AdminBean(adminid,password,name,phonenumber))) {
			return "Admin Registered Sucessfully";}
		else {
		    return "Admin not registered ";
		}
	
	}

	public String addCategory(String type) {
		if(category.add(new CategoryBean(type)))
		{
			return "Category added successfully";
		}
		else 
		return "Category adding failed";
	}
  //public customer viewUsers()
}
