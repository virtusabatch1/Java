package com.virtusa.service;

import java.util.ArrayList;

//import com.virtusa.bean.CardBean;
import com.virtusa.bean.UserBean;

public class UserService {
	
   ArrayList<UserBean> customer=new ArrayList<UserBean>();
  
   
     public boolean login(String username,String password) {

	   boolean  res = false;
	   
	   for(int i=0;i<customer.size();i++) {
		   
		   UserBean ub =customer.get(i);
		   if(ub.getName().equals(username)&&ub.getPasssword().equals(password)){
			   res = true;
		   }
	   }
	   
	   return res;
	   
   }
   
   

   void selectCategory() {
	   
   }
   void viewitem() {
	   
   }
   void addAdress() {
	   
   }
   void cardDetails() {
	   
   }
   void placeOrder() {
	   
   }

		public String registration(int userid, String password, String username, long phonenumber) {
			
			if(customer.add(new UserBean(userid,password,username,phonenumber))) {
				return "user Registered Sucessfully";}
			else {
			    return "user not registered ";
			}
			
			
		}

}
