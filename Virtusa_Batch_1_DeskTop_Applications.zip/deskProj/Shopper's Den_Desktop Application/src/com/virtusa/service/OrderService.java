package com.virtusa.service;

import java.util.ArrayList;

import com.virtusa.bean.OrderBean;

public class OrderService {
	ArrayList<OrderBean> order=new ArrayList<OrderBean>();
	public String place_order(int order_id,String status, String user_address) {
		if(order.add(new OrderBean(order_id,status,user_address))) {
		return "order placed successfully";	
		}else
		{
			return "order not placed";
		}
		
	}

}
