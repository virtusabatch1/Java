package com.virtusa.service;

import java.util.ArrayList;

import com.virtusa.bean.CardBean;
import com.virtusa.bean.CartBean;

public class CartService {
	ArrayList<CartBean> cart=new ArrayList<CartBean>();
	public String cart_data(int item_id2,String item_name2,double item_cost2)
	{
		if(cart.add(new CartBean(item_id2,item_name2,item_cost2))) {
		return "Items added to cart successfully";}
		else {
			return "Items adding failed";}
			}
		}
	
	


