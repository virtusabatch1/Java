package com.virtusa.Main;
import com.virtusa.bean.*;
import com.virtusa.service.*;
import com.virtusa.service.AdminService;
import java.util.*;

public class MainClass {
	
	static ArrayList<UserBean> customer=new ArrayList<UserBean>();
	private static UserService us=new UserService();
	private static AdminService as=new AdminService();
	private static CardService cs=new CardService();
	private static CartService ct=new CartService();
	private static OrderService os=new OrderService();
	public static void main(String[] ar) {
		  
		double ud = 0;
		Scanner sc=new Scanner(System.in);
		 String res=" ";
		String response="continue";
		int order_id=0;
		do {
			
		System.out.println("**********Welcome to Shopper's Den***********");
		System.out.println("1.New user-Register\n2.User-Login\n3.Admin-page");
		System.out.print("Enter ur choice: ");
		int ch=sc.nextInt();
		switch(ch) {
		case 1: 
				System.out.println("*****User-Registration******");
				System.out.println("Enter User Id : ");
				int Userid=sc.nextInt();
				System.out.println("Enter Password: ");
				String password=sc.next();
				System.out.println("Enter Name: ");
				String username=sc.next();
				System.out.println("Enter Phone number: ");
				long phonenumber=sc.nextLong();
				System.out.print(us.registration(Userid,password,username,phonenumber));
				System.out.print("\n");
				break;
				
		case 2:System.out.println("**** User Login*****");
				System.out.println("Enter User name: ");
				String Username=sc.next();
				System.out.println("Enter pasword: ");
				String Password=sc.next();
				 if(us.login(Username,Password)) {
					 System.out.println("Logged in Sucessfully");
				 	System.out.print("\n");
				
					
				do {
					 System.out.println("Select a Category");
					 System.out.println("1.Men\n2.Women\n3.Electronics");
					 int ch1=sc.nextInt();
				 switch(ch1)
				 {
				 
				 case 1:System.out.println("This is Men's category");
				 		System.out.println("Choose:\n1.Footwear\n2.Clothing\n");
				 		int i;
				 		i=sc.nextInt();
				 		//j=sc.nextInt();
				 		if(i==1) {
				 			System.out.println("You have selected Footwear section");
				 			System.out.println("1.Puma shoes-3999\n2.adidas shoes-1599\n3.Reebok-2999\n4.Nike shoes-1999");
				 			System.out.println("Select items to add to your cart: ");
				 			int j;
				 			j=sc.nextInt();
				 			if(j==1) {
				 				System.out.println(ct.cart_data(501, "Puma", 3999));
				 			
				 			}
				 			else if(j==2) {
				 				System.out.println(ct.cart_data(502, "adidas", 1599));
				 		
				 			}
				 			else if(j==3) {
				 				System.out.println(ct.cart_data(503, "Reebok", 2999));
				 				
				 			}
				 			else if(j==4) {
				 				System.out.println(ct.cart_data(504, "Nike", 1999));
				 			
				 			}
				 			else {
				 				System.out.println("enter a valid choice");
				 			}
				 			
				 		}else if(i==2)
				 		{
				 			System.out.println("You have selected Clothing section");
				 			System.out.println("1.Levi's shirt-1299\n2.Tommy Hilfiger Pant-1999\n3.U.S Polo T-shirt-999\n4.Louis Philipe shirt-1399");
				 			System.out.println("Select items to add to your cart: ");
				 			int j;
				 			j=sc.nextInt();
				 			if(j==1) {
				 				System.out.println(ct.cart_data(601, "Levi's shirt", 1299));
				 				
				 			}
				 			else if(j==2) {
				 				System.out.println(ct.cart_data(602, "Tommy Hilfiger Pant", 1999));
				 				
				 			}
				 			else if(j==3) {
				 				System.out.println(ct.cart_data(603, "U.S Polo T-shirt", 999));
				 				
				 			}
				 			else if(j==4) {
				 				System.out.println(ct.cart_data(604, "Louis Philipe shirt", 1399));
				 				
				 			}
				 			else {
				 				System.out.println("enter a valid choice");
				 			}
				 		}
				 			else {
				 				System.out.println("enter a valid choice");
				 			}
				 		break;
				 		
				 					 		
				 case 2:System.out.println("This is Women's category");
				 		System.out.println("Choose:\n1.Footwear\n2.Clothing\n");
				 		int k;
				 		k=sc.nextInt();
				 		//j=sc.nextInt();
				 		if(k==1) {
				 			System.out.println("You have selected Footwear section");
				 			System.out.println("1.Puma shoes-3999\n2.adidas shoes-1599\n3.Reebok-2999\n4.Nike shoes-1999");
				 			System.out.println("Select items to add to your cart: ");
				 			int j;
				 			j=sc.nextInt();
				 			if(j==1) {
				 				System.out.println(ct.cart_data(701, "Puma", 3999));
				 				
				 			}
				 			else if(j==2) {
				 				System.out.println(ct.cart_data(702, "adidas", 1599));
				 			
				 			}
				 			else if(j==3) {
				 				System.out.println(ct.cart_data(703, "Reebok", 2999));
				 			
				 			}
				 			else if(j==4) {
				 				System.out.println(ct.cart_data(704, "Nike", 1999));
				 		
				 			}
				 			else {
				 				System.out.println("enter a valid choice");
				 			}
				 			
				 		}else if(k==2)
				 		{
				 			System.out.println("You have selected Clothing section");
				 			System.out.println("1.Nayo Kurtis-999\n2.Ethnic wear-2999\n3.Indo-Western -999\n4.Western tops-1399\n5.Denim-Jeans-1999" );
				 			System.out.println("Select items to add to your cart: ");
				 			int j;
				 			j=sc.nextInt();
				 			if(j==1) {
				 				System.out.println(ct.cart_data(801, "Nayo Kurtis", 999));
				 			
				 			}
				 			else if(j==2) {
				 				System.out.println(ct.cart_data(802, "Ethnic wear", 2999));
				 			
				 			}
				 			else if(j==3) {
				 				System.out.println(ct.cart_data(803, "Indo-Western", 999));
				 				
				 			}
				 			else if(j==4) {
				 				System.out.println(ct.cart_data(804, "Western tops", 1399));
				 			
				 			}
				 			else if(j==5) {
				 				System.out.println(ct.cart_data(805, "Denim-Jeans", 1399));
				 				
				 			}
				 			else {
				 				System.out.println("Enter a valid choice");
				 			}
				 		}
				 			else {
				 				System.out.println("Enter a valid choice");
				 			}
				 		break;
				 		
				 case 3:System.out.println("This is Electronics category");
				 		System.out.println("Choose:\n 1.Mobiles\n 2.Laptops\n");
				 		int l;
				 		l=sc.nextInt();
				 		//j=sc.nextInt();
				 		if(l==1) {
				 			System.out.println("You have selected Mobiles section");
				 			System.out.println("1.Samsung S10+ - 69999\n2.1+ 7 Pro - 52999\n3.Realme 5 Pro - 18999\n4.Mi Note 7 Pro - 15999");
				 			System.out.println("Select items to add to your cart: ");
				 			int j;
				 			j=sc.nextInt();
				 			if(j==1) {
				 				System.out.println(ct.cart_data(901, "Samsung S10+", 69999));
				 				
				 			}
				 			else if(j==2) {
				 				System.out.println(ct.cart_data(902, "1+ 7 Pro", 52999));
				 				
				 			}
				 			else if(j==3) {
				 				System.out.println(ct.cart_data(903, "Realme 5 Pro", 18999));
				 				
				 			}
				 			else if(j==4) {
				 				System.out.println(ct.cart_data(904, "Mi Note 7 Pro", 15999));
				 			
				 			}
				 			else {
				 				System.out.println("Enter a valid choice");
				 			}
				 			
				 		}else if(l==2)
				 		{
				 			System.out.println("You have selected Laptops section");
				 			System.out.println("1.Dell Inspiron-79,999\n2.asus Zenbook - 80,999\n3.Apple Macbook Pro-2,31,000\n4.hp Spectra - 1,65,000");
				 			System.out.println("Select items to add to your cart: ");
				 			int j;
				 			j=sc.nextInt();
				 			if(j==1) {
				 				System.out.println(ct.cart_data(111, "Dell Inspiron", 79999));
				 				
				 			}
				 			else if(j==2) {
				 				System.out.println(ct.cart_data(112, "asus Zenbook", 80999));
				 			
				 			}
				 			else if(j==3) {
				 				System.out.println(ct.cart_data(113, "Apple Macbook Pro", 231000));
				 				
				 			}
				 			else if(j==4) {
				 				System.out.println(ct.cart_data(114, "hp Spectra", 165000));
				 				
				 			}
				 			else {
				 				System.out.println("Enter a valid choice");
				 			}
				 		}
				 			else {
				 				System.out.println("Enter a valid choice");
				 			}
				 }
				 System.out.println("Enter your choice\n1.Continue Shopping\n2.Place Order");
					
				 int check=sc.nextInt();
					if(check==1)
						  res= "continue";
					else
					{
						System.out.println("Enter your Credit card details to place order: ");
						System.out.println("Enter your card_number: ");
						double card_no=sc.nextDouble();
						System.out.println("Enter your card date of issue: ");
						String date_of_issue=sc.next();
						System.out.println("Enter your card expiry date:");
						String date_of_expiry=sc.next();
						double user_id=ud;
						System.out.println(cs.card_data(card_no,date_of_issue,date_of_expiry,user_id));
						//--------------------------------------------
						order_id=(int)(Math.random()*(8000-5000+1)+5000);
						System.out.println("Enter shipping address:");
					    String address=sc.next();
					    String status= "Order Confirmed";
					    System.out.println("1.Confirm Order\n2.Cancel Order");
					     int ch4=sc.nextInt();
					     if(ch4==1) {
					    	 System.out.println("Order Summary:");
					    	 System.out.println(os.place_order(order_id, status, address));
					    	 System.out.println("O_id:"+order_id+",Order_status:"+status+",Shipping_address:"+address);
					    	 System.out.println("________________________________________");
					         res = "exit";
					     }else
					     {
					    	System.out.println("Order not placed");
					     }
						}
					
					}while(res.equals("Continue"));
				 }
				 else {
					 System.out.println("Logging in failed");
				 	}
				 break;
		case 3:	
				System.out.println("******Admin Page******");
				System.out.println("1.Admin Register\n2.Admin Login");
				System.out.println("enter your choice:");
				int ch3=sc.nextInt();
				switch(ch3) {
				case 1:			System.out.print("Enter Admin Id: ");
								int adminid=sc.nextInt();
								System.out.print("Enter Password: ");
								String adminpassword=sc.next();
								System.out.println("enter name: ");
								String adminname=sc.next();
								System.out.println("Enter Phone number: ");
								long phonenumb=sc.nextLong();
								System.out.println(as.adminregistration(adminid,adminpassword,adminname,phonenumb));
								System.out.println("\n");	
								break;
			    case 2:         System.out.println("*****Admin--Login*****");
								System.out.println("enter adminid: ");
								int  Adminid=sc.nextInt();
								System.out.println("enter password: ");
								password=sc.next();
								if(as.adminLogin(Adminid,password)) {
									System.out.println("Admin loggedin");
									System.out.print("\n");
								}
								else {
									System.out.println("log in failed");
								}
								break;
			   
			   
			    default:		System.out.println("Enter valid choice");
				}					
		}
		System.out.println("\n");
		System.out.println("Enter your choice\n1.Shooper's-Den\n2.Logout");
	 	int check=sc.nextInt();
		if(check==1)
			response = "continue";
		else
			response = " exit";
		
		}while(response.equals("continue"));
	sc.close();
	}

}
