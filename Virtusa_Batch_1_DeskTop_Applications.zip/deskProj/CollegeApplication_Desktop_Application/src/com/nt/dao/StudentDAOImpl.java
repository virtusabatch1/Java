package com.nt.dao;

import java.util.ArrayList;
import java.util.List;

import com.nt.bo.StudentBO;
import com.nt.service.StudentService;
import com.nt.service.StudentServiceImpl;

public class StudentDAOImpl implements StudentDAO {
	
	@Override
	public List<StudentBO> insertStudentDetails(StudentBO bo) throws Exception {
		List<StudentBO> listBO=null;
		
		listBO=new ArrayList();
		listBO.add(bo);
		return listBO;
	}
	public  List<StudentBO> getStudentDetails()throws Exception{
		List<StudentBO> listBO=null;
		listBO=new ArrayList<>();
		StudentBO bo=new StudentBO();
		bo.setSno(104);
		bo.setName("Fyroz");
		bo.setAge(23);
		bo.setAddress("HYD");
		listBO.add(bo);
		
		
		
		return listBO;
		
	}

}
