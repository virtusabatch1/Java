package com.nt.dao;

import java.util.ArrayList;
import java.util.List;

import com.nt.bo.AdministratorBO;
import com.nt.bo.StudentBO;


public class AdministratorDAOImpl implements AdministratorDAO {

	@Override
	public List<AdministratorBO> insertAdministratorDetails(AdministratorBO bo) throws Exception {
		List<AdministratorBO> listBO=null;
		listBO=new ArrayList();
		//add bo object to listBO
		listBO.add(bo);
		return listBO;
		
	}//method
	
	public  List<AdministratorBO> getAdministratorDetails()throws Exception{
		List<AdministratorBO> listBO=null;
		listBO=new ArrayList<>();
		AdministratorBO bo=new AdministratorBO();
		bo.setAdminID(152);
		bo.setAdminName("Sudha");
		
		listBO.add(bo);
		
		
		
		return listBO;
		
	}
}//class
