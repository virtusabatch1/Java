package com.nt.dao;

import java.util.List;

import com.nt.bo.AdministratorBO;

public interface AdministratorDAO {
	public List<AdministratorBO> insertAdministratorDetails(AdministratorBO bo) throws Exception;
	public  List<AdministratorBO> getAdministratorDetails()throws Exception;
}
