package com.nt.dao;

import java.util.ArrayList;
import java.util.List;

import com.nt.bo.AlumniBO;
import com.nt.bo.StudentBO;

public class AlumniDAOImpl implements AlumniDAO{

	@Override
	public List<AlumniBO> insertAlumniDetails(AlumniBO bo) throws Exception {
		List<AlumniBO> listBO=null;
		listBO=new ArrayList();
		//add bo object to listBO
		listBO.add(bo);
		return listBO;
	}
   
	public  List<AlumniBO> getAlumniDetails()throws Exception{
		List<AlumniBO> listBO=null;
		listBO=new ArrayList<>();
		AlumniBO bo=new AlumniBO();
		bo.setAlumID(142);
		bo.setAlumName("Navya");
		bo.setYop(2019);
		
		listBO.add(bo);
		
		
		
		return listBO;
		
	}
}//class
