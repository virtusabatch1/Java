package com.nt.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.nt.bo.ApplicantBO;


public class ApplicantDAOImpl implements ApplicantDAO {

	@Override
	public List<ApplicantBO> insertApplicantDetails(ApplicantBO bo) throws Exception {
		List<ApplicantBO> listBO=null;
		//ApplicantBO bo=null;
		
		listBO=new ArrayList<>();
//		//bo=new ApplicantBO();
//		bo.getFirstName();
//		System.out.println("4th..........");
//		bo.getLastName();
//		bo.getCourse();
//		bo.getEmailID();
//		bo.getPhNO();
//		bo.getDob();
//		//add bo to list bo
		listBO.add(bo);

		return listBO;
	}
	

}
