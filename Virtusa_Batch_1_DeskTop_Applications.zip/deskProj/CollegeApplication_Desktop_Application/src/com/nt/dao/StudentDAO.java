package com.nt.dao;

import java.util.List;


import com.nt.bo.StudentBO;

public interface StudentDAO {
	public List<StudentBO> insertStudentDetails(StudentBO bo) throws Exception;

	public List<StudentBO> getStudentDetails()throws Exception;

	
}
