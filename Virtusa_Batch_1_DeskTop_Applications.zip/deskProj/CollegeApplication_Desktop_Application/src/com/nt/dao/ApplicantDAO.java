package com.nt.dao;

import java.util.List;

import com.nt.bo.ApplicantBO;

public interface ApplicantDAO{
	public List<ApplicantBO> insertApplicantDetails(ApplicantBO bo) throws Exception;
}

