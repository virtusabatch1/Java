package com.nt.dao;

import java.util.List;

import com.nt.bo.FacultyBO;

public interface FacultyDAO {
	public List<FacultyBO> insertFacultyDetails(FacultyBO bo)throws Exception;
	public  List<FacultyBO> getFacultyDetails()throws Exception;
	}