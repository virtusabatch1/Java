package com.nt.dao;

import java.util.List;

import com.nt.bo.AlumniBO;
 
public interface AlumniDAO{
	public List<AlumniBO> insertAlumniDetails(AlumniBO bo) throws Exception;
	public  List<AlumniBO> getAlumniDetails()throws Exception;

}
