package com.nt.dao;

import java.util.ArrayList;
import java.util.List;

import com.nt.bo.FacultyBO;
import com.nt.bo.StudentBO;


public class FacultyDAOImpl implements FacultyDAO{
	@Override
	public List<FacultyBO> insertFacultyDetails(FacultyBO bo) throws Exception {
		List<FacultyBO> listBO=null;
		
		listBO=new ArrayList();
		listBO.add(bo);
		return listBO;
	}
	
	public  List<FacultyBO> getFacultyDetails()throws Exception{
		List<FacultyBO> listBO=null;
		listBO=new ArrayList<>();
		FacultyBO bo=new FacultyBO();
		bo.setfID(112);
		bo.setName("Vamsi");
		bo.setAge(23);
		bo.setAddress("HYD");
		listBO.add(bo);
		
		
		
		return listBO;
		
	}
}//class
