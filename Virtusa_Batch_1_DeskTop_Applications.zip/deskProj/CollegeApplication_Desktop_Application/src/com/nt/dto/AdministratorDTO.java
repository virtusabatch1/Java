package com.nt.dto;

import com.nt.controller.StudentController;

public class AdministratorDTO {
	private int adminID;
	private String AdminName;
	
	
	public int getAdminID() {
		return adminID;
	}
	public void setAdminID(int adminID) {
		this.adminID = adminID;
	}
	public String getAdminName() {
		return AdminName;
	}
	public void setAdminName(String adminName) {
		AdminName = adminName;
	}
	
	@Override
	public String toString() {
		return "AdministratorDTO [adminID=" + adminID + ", AdminName=" + AdminName + "]";
	}
	
	

}
