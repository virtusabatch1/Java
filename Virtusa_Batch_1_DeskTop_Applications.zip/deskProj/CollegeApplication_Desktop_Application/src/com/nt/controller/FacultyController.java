package com.nt.controller;

import java.util.List;
import java.util.Scanner;

import com.nt.dto.FacultyDTO;
import com.nt.dto.StudentDTO;
import com.nt.service.FacultyService;
import com.nt.service.FacultyServiceImpl;

public class FacultyController {
	private FacultyService service;
	//Constructor
	public FacultyController() {
		service=new FacultyServiceImpl();
	}
	
	public void process() throws Exception{
		FacultyDTO dto=null;
		Scanner sc=null;
		String insert=null;
		sc=new Scanner(System.in);
		System.out.println("Enter the Faculty ID:");
		int fID=sc.nextInt();
		System.out.println("Enter the Name:");
		String Name=sc.next();
		System.out.println("Enter the age:");
		int age=sc.nextInt();
		System.out.println("Enter the Address:");
		String Address=sc.next();
		
		//Create dto class obj
		dto=new FacultyDTO();
		dto.setfID(fID);
		dto.setName(Name);
		dto.setAge(age);
		dto.setAddress(Address);
		try {
			insert=service.generateFacultyDetails(dto);
			System.out.println(insert);
		}
		catch(Exception e){e.printStackTrace();
		}
		
	}//method
	public void login() {
		Scanner input = new Scanner(System.in);

	    String user="Faculty1";
	    String pass="virtusa";

	    System.out.println("Log in:");
	    System.out.println("username: ");
	   String username = input.next();

	    System.out.println("password: ");
	  String password = input.next();

	    //users check = new users(username, password);

	    if (user.equals(username) && pass.equals(password)) {

	        System.out.println("Access Granted! Welcome to Student Portal!");
	    }

	    else if (user.equals(username)) {
	        System.out.println("Invalid Password!");
	        System.exit(0);
	        
	    } else if (pass.equals(password)) {
	        System.out.println("Invalid Username!");
	        System.exit(0);
	    } else {
	        System.out.println("Invalid Username & Password!");
	        System.exit(0);
	    }
	    	

	}//login
	
	
	public List<FacultyDTO>controllerProcess()throws Exception {
		List<FacultyDTO> listdto=null;
			
		    listdto=service.ProcessFacultyDetails();
		    System.out.println(listdto);
			
			return listdto;
			
			
		}
	
	

}//class
