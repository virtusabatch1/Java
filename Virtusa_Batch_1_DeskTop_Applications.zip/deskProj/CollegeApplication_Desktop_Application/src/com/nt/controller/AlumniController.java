package com.nt.controller;

import java.util.List;
import java.util.Scanner;

import com.nt.dto.AlumniDTO;
import com.nt.dto.StudentDTO;
import com.nt.service.AlumniService;
import com.nt.service.AlumniServiceImpl;

public class AlumniController {
	private AlumniService service;
	
	public AlumniController() {
		service=new AlumniServiceImpl();
		}
	public void process()throws Exception{
		AlumniDTO dto=null;
		Scanner sc=null;
		String insert=null;
		sc=new Scanner(System.in);
		System.out.println("Enter the AlumniID:");
		int id=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the AlumniName:");
		String name=sc.nextLine();
		System.out.println("Enter the Year OF Pass:");
		int yop=sc.nextInt();
		
		//convert Scanner class obj to dto class obj
		dto=new AlumniDTO();
		dto.setAlumID(id);
		dto.setAlumName(name);
		dto.setYop(yop);
		
		//create and use Service class object
		try {
			System.out.println("...................");
			insert=service.generateAlumniDetails(dto);
			System.out.println(insert);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	
	}//method
	public void login() {
		Scanner input = new Scanner(System.in);

	    String user="Alumni1";
	    String pass="virtusa";

	    System.out.println("Log in:");
	    System.out.println("username: ");
	   String username = input.next();

	    System.out.println("password: ");
	  String password = input.next();

	    //users check = new users(username, password);

	    if (user.equals(username) && pass.equals(password)) {

	        System.out.println("Access Granted! Welcome to Student Portal!");
	    }

	    else if (user.equals(username)) {
	        System.out.println("Invalid Password!");
	        System.exit(0);
	        
	    } else if (pass.equals(password)) {
	        System.out.println("Invalid Username!");
	        System.exit(0);
	    } else {
	        System.out.println("Invalid Username & Password!");
	        System.exit(0);
	    }
	    	

	}//login
	
	public List<AlumniDTO>controllerProcess()throws Exception {
		List<AlumniDTO> listdto=null;
			
		    listdto=service.ProcessAlumniDetails();
		    System.out.println(listdto);
			
			return listdto;
			
			
		}
}//class
