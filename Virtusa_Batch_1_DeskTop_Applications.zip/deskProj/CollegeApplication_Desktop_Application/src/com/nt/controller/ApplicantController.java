package com.nt.controller;

import java.util.Scanner;

import com.nt.dto.ApplicantDTO;
import com.nt.service.ApplicantService;
import com.nt.service.ApplicantServiceImpl;

public class ApplicantController {
    private ApplicantService service;
    
    //Constructor
    public ApplicantController() {
		service=new ApplicantServiceImpl();	
			
    }
    
	public void process()throws Exception{
		ApplicantDTO dto=null;
		Scanner sc=null;
		String fName,lName,course,dob,email=null;
		long phno=0;
		String insert=null;
		//create Scanner class Obj
		sc=new Scanner(System.in);
		System.out.println("Enter the First Name:");
		fName=sc.nextLine();
		System.out.println("Enter the Last Name:");
		lName=sc.nextLine();
		System.out.println("Enter the course:");
		course=sc.nextLine();
		System.out.println("Enter the Email:");
		email=sc.nextLine();
		System.out.println("Enter the phno:");
		phno=sc.nextLong();
		sc.nextLine();
		System.out.println("Enter the dob:");
		dob=sc.nextLine();
		
		//convert Scanner class obj to dto class obj
		dto=new ApplicantDTO();
		dto.setFirstName(fName);
		dto.setLastName(lName);
		dto.setCourse(course);
		dto.setEmailID(email);
		dto.setPhNO(phno);
		dto.setDob(dob);
		
		//create and use Service class object
		try {
			System.out.println("...................");
			insert=service.generateApplicantDetails(dto);
			System.out.println(insert);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}//method
		
		
		
		
		
	
}//class
