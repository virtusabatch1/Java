package com.nt.controller;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.nt.bo.ApplicantBO;
import com.nt.dto.AdministratorDTO;
import com.nt.service.AdministratorService;
import com.nt.service.AdministratorServiceImpl;

public class AdministratorController {
	private AdministratorService service;
	
	//Constructor
	public  AdministratorController() {
		service=new AdministratorServiceImpl();
	}
	
	public void process() throws Exception{
		AdministratorDTO dto=null;
		Scanner sc=null;
		String insert=null;
		sc=new Scanner(System.in);
		System.out.println("Enter the AdminID:");
		int AdminID=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the AdminName:");
		String AdminName=sc.nextLine();
		
		//create dto obj
		dto=new AdministratorDTO();
		dto.setAdminID(AdminID);
		dto.setAdminName(AdminName);
		
		
		//use Service
		try {
		insert=service.generateAdministratorDetails(dto);
		System.out.println(insert);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}//method
	public void login() {
		Scanner input = new Scanner(System.in);

	    String user="Admin1";
	    String pass="virtusa";

	    System.out.println("Log in:");
	    System.out.println("username: ");
	   String username = input.next();

	    System.out.println("password: ");
	  String password = input.next();

	    //users check = new users(username, password);

	    if (user.equals(username) && pass.equals(password)) {

	        System.out.println("Access Granted! Welcome to Student Portal!");
	    }

	    else if (user.equals(username)) {
	        System.out.println("Invalid Password!");
	        System.exit(0);
	        
	    } else if (pass.equals(password)) {
	        System.out.println("Invalid Username!");
	        System.exit(0);
	    } else {
	        System.out.println("Invalid Username & Password!");
	        System.exit(0);
	    }
	    	

	}//login
	
	public List<AdministratorDTO>controllerProcess()throws Exception {
		List<AdministratorDTO> listdto=null;
			
		    listdto=service.ProcessAdministratorDetails();
		    System.out.println(listdto);
			
			return listdto;
			
			
		}
	
	public List<ApplicantBO> checkApplicantData(List count){
		 System.out.println("====Check Applicant Data===");
		  System.out.println(count);
 	  System.out.println("Your data is approved "+new Date());
		 
		   
		return count;
		
	}


}//class
