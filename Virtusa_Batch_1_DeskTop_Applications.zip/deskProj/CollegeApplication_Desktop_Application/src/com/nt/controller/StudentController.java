package com.nt.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.nt.dto.StudentDTO;
import com.nt.service.StudentService;
import com.nt.service.StudentServiceImpl;

public class StudentController {
	private StudentService service;
	
	//Constructor
	public StudentController() {
		service=new StudentServiceImpl();
	}
	
	public void process() throws Exception{
		StudentDTO dto=null;
		Scanner sc=null;
		String insert=null;
		sc=new Scanner(System.in);
		System.out.println("Enter the SNo:");
		int sno=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the Name:");
		String name=sc.nextLine();
		System.out.println("Enter the Address:");
		String addr=sc.nextLine();
		System.out.println("Enter the age:");
		int age=sc.nextInt();
		
		//create dto obj
		dto=new StudentDTO();
		dto.setSno(sno);
		dto.setName(name);
		dto.setAddress(addr);
		dto.setAge(age);
		
		//use Service
		try {
		insert=service.generateStudentDetails(dto);
		System.out.println(insert);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}//method
	public void login() {
		Scanner input = new Scanner(System.in);

	    String user="Student1";
	    String pass="virtusa";

	    System.out.println("Log in:");
	    System.out.println("username: ");
	   String username = input.next();

	    System.out.println("password: ");
	  String password = input.next();

	    //users check = new users(username, password);

	    if (user.equals(username) && pass.equals(password)) {

	        System.out.println("Access Granted! Welcome to Student Portal!");
	    }

	    else if (user.equals(username)) {
	        System.out.println("Invalid Password!");
	        System.exit(0);
	        
	    } else if (pass.equals(password)) {
	        System.out.println("Invalid Username!");
	        System.exit(0);
	    } else {
	        System.out.println("Invalid Username & Password!");
	        System.exit(0);
	    }
	    	

	}//login
	public List<StudentDTO>controllerProcess()throws Exception {
	List<StudentDTO> listdto=null;
		
	    listdto=service.ProcessStudentDetails();
	    System.out.println(listdto);
		
		return listdto;
		
		
	}

}//class
