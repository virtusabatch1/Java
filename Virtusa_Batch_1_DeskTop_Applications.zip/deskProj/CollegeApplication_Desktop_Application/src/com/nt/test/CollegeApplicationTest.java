package com.nt.test;

import java.util.Scanner;

import com.nt.controller.AdministratorController;
import com.nt.controller.AlumniController;
import com.nt.controller.ApplicantController;
import com.nt.controller.FacultyController;
import com.nt.controller.StudentController;

public class CollegeApplicationTest {

	public static void main(String[] args) throws Exception {
		try {
		Scanner sc=null;
		sc=new Scanner(System.in);
	
		while(true)
		{
		System.out.print("\n========Virtusa College==========\n1)Login\n2)Applicant\n");
		//3)Student\n4)Faculty\n5)Admin\n6)Alumni
		System.out.println("To Logout type -1");
		System.out.println("Enter the choice: ");
		int num=sc.nextInt();
		if(num == -1)
		{
		break;
		}
		switch(num)
		{
		 case 1:
			 System.out.println("=====Menu=====");
			 System.out.println("\n1)Student\n2)Faculty\n3)Admin\n4)Alumni");
			 System.out.println("Enter the choice: ");
			 int num1=sc.nextInt();
			 switch(num1)
			 {
			 case 1:
				 System.out.println("===Welcome to Student Portal===");
				 StudentController sc1=new StudentController();
				    sc1.login();
				    System.out.println("======Menu=====");
				    System.out.println("\n1)INSERT\n2)VIEW");
				    System.out.println("Enter the choice: ");
				    int n1=sc.nextInt();
				    switch(n1) {
				    case 1: 
				    	  System.out.println("Fill the Student Details");
				    	  sc1.process();			            
				            break;
				    case 2:
				    	System.out.println("====Student Details====");
				    	sc1.controllerProcess();				    			
		 		    break;
				    default:
						 System.out.println("=============================================================");
						 System.out.print("Wrong key Pressed,please enter the correct key\n");
						 System.out.println("Try again...!!!");
						 System.out.println("=============================================================");
				    }//Switch n1
				    break;
			 case 2:
				 System.out.println("===Welcome to Faculty Portal===");
				 FacultyController fc=new FacultyController();
				   fc.login();
				    System.out.println("======Menu=====");
				    System.out.println("\n1)INSERT\n2)VIEW");
				    System.out.println("Enter the choice: ");
				    int n2=sc.nextInt();
				    switch(n2) {
				    case 1: 
				    	  System.out.println("Fill the Student Details");
				    	  fc.process();			            
				            break;
				    case 2:
				    	System.out.println("====Faculty Details====");
				    	fc.controllerProcess();				    			
		 		    break;
				    default:
						 System.out.println("=============================================================");
						 System.out.print("Wrong key Pressed,please enter the correct key\n");
						 System.out.println("Try again...!!!");
						 System.out.println("=============================================================");
				    }//Switch n2
				    break;
			 case 3:
		    	 System.out.println("===Welcome to Admin Portal===");
		    	 AdministratorController ac2=new AdministratorController();
		    	 ac2.login();
		    	 System.out.println("======Menu=====");
				    System.out.println("\n1)INSERT\n2)VIEW");
				    System.out.println("Enter the choice: ");
				    int n3=sc.nextInt();
				    switch(n3) {
				    case 1: 
				    	  System.out.println("Fill the ADMIN Details");
				    	  ac2.process();			            
				            break;
				    case 2:
				    	System.out.println("====Admin Details====");
				    	ac2.controllerProcess();				    			
		 		    break;
				    default:
						 System.out.println("=============================================================");
						 System.out.print("Wrong key Pressed,please enter the correct key\n");
						 System.out.println("Try again...!!!");
						 System.out.println("=============================================================");
				    }//Switch n3
				    break;
		     case 4:
		    	 System.out.println("Welcome to Alumni Portal");
		    	 AlumniController ac1=new AlumniController();
		    	    ac1.login();
		    	    System.out.println("======Menu=====");
				    System.out.println("\n1)INSERT\n2)VIEW");
				    System.out.println("Enter the choice: ");
				    int n4=sc.nextInt();
				    switch(n4) {
				    case 1: 
				    	  System.out.println("Fill the ADMIN Details");
				    	  ac1.process();			            
				            break;
				    case 2:
				    	System.out.println("====Alumni Details====");
				    	ac1.controllerProcess();				    			
		 		    break;
				    default:
						 System.out.println("=============================================================");
						 System.out.print("Wrong key Pressed,please enter the correct key\n");
						 System.out.println("Try again...!!!");
						 System.out.println("=============================================================");
				    }//Switch n1
				    break;
			 }//switch2
		 		break;
		    
		 case 2:
			 System.out.println("===Welcome to Applicant Portal===");
			 ApplicantController ac=new ApplicantController();
			    
				ac.process();
				break;
		
		 
		 default:
			 System.out.println("=============================================================");
			 System.out.print("Wrong key Pressed,please enter the correct key\n");
			 System.out.println("Try again...!!!");
			 System.out.println("=============================================================");
		     
		  }//switch
		}//while
		
	}//try
		catch(Exception e)
		{
		System.out.println("NOTE: \n"+"Please enter specified key format..!!!");
		System.out.println("======================================");
		System.out.println("Now you are Signing out");
		System.out.println("Thank You,Login Again");
		System.out.println("======================================"); 
		}
	
 }//main


}//class
