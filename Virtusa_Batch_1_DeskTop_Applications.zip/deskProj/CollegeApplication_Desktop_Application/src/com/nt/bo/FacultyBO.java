package com.nt.bo;

public class FacultyBO {
	private int fID;
	private String Name;
	private int age;
	private String address;
	
	public int getfID() {
		return fID;
	}
	public void setfID(int fID) {
		this.fID = fID;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	//ToString
	@Override
	public String toString() {
		return "FacultyBO [fID=" + fID + ", Name=" + Name + ", age=" + age + ", address=" + address + "]";
	}
}//class
