package com.nt.bo;

public class ApplicantBO {
	   private  String firstName;
	   private  String lastName;
	   private  String course;
	   private  String emailID;
	   private  long phNO;
	   private  String Dob;
	     
	     //Generate Setter and Getter methods
	     public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public String getCourse() {
			return course;
		}
		public void setCourse(String course) {
			this.course = course;
		}
		public String getEmailID() {
			return emailID;
		}
		public void setEmailID(String emailID) {
			this.emailID = emailID;
		}
		public long getPhNO() {
			return phNO;
		}
		public void setPhNO(long phNO) {
			this.phNO = phNO;
		}
		public String getDob() {
			return Dob;
		}
		public void setDob(String dob) {
			Dob = dob;
		}
		@Override
		public String toString() {
			return "ApplicantBO [firstName=" + firstName + ", lastName=" + lastName + ", course=" + course + ", emailID="
					+ emailID + ", phNO=" + phNO + ", Dob=" + Dob + "]";
		}
		
	}//class
