package com.nt.bo;

import com.nt.controller.StudentController;

public class AdministratorBO {
	private int adminID;
	private String AdminName;
	
	
	public int getAdminID() {
		return adminID;
	}
	public void setAdminID(int adminID) {
		this.adminID = adminID;
	}
	public String getAdminName() {
		return AdminName;
	}
	public void setAdminName(String adminName) {
		AdminName = adminName;
	}
	
	@Override
	public String toString() {
		return "AdministratorBO [adminID=" + adminID + ", AdminName=" + AdminName + "]";
	}

}
