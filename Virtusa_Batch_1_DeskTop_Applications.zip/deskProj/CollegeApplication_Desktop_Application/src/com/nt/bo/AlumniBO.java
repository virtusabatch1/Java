package com.nt.bo;

public class AlumniBO {
     
	private int alumID;
	 private String alumName;
	 private int yop;
	 
	public int getAlumID() {
		return alumID;
	}
	public void setAlumID(int alumID) {
		this.alumID = alumID;
	}
	public String getAlumName() {
		return alumName;
	}
	public void setAlumName(String alumName) {
		this.alumName = alumName;
	}
	public int getYop() {
		return yop;
	}
	public void setYop(int yop) {
		this.yop = yop;
	}
	
	@Override
	public String toString() {
		return "AlumniBO [alumID=" + alumID + ", alumName=" + alumName + ", yop=" + yop + "]";
	}
	
	

}
