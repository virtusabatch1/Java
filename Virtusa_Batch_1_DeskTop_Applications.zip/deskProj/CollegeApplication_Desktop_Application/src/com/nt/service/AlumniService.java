package com.nt.service;


import java.util.List;

import com.nt.dto.AlumniDTO;


public interface AlumniService {
	public String generateAlumniDetails(AlumniDTO dto) throws Exception;
	public  List<AlumniDTO> ProcessAlumniDetails() throws Exception ; 
         
	
}
