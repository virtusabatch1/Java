package com.nt.service;

import java.util.List;

import com.nt.dto.FacultyDTO;

public interface FacultyService {
	public String generateFacultyDetails(FacultyDTO dto) throws Exception;
	public  List<FacultyDTO> ProcessFacultyDetails() throws Exception;
}
