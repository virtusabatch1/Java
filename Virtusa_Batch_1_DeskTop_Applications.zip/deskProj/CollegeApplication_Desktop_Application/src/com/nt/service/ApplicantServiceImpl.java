package com.nt.service;

import java.util.ArrayList;
import java.util.List;

import com.nt.bo.ApplicantBO;
import com.nt.controller.AdministratorController;
import com.nt.dao.ApplicantDAO;
import com.nt.dao.ApplicantDAOImpl;
import com.nt.dto.ApplicantDTO;

public class ApplicantServiceImpl implements ApplicantService,Runnable {
	private ApplicantDAO dao;
	private AdministratorController ac;
	
	//Constructor
	public ApplicantServiceImpl() {
		dao=new ApplicantDAOImpl();
		ac=new AdministratorController();
	}//constructor()

	@Override
	public String generateApplicantDetails(ApplicantDTO dto) throws Exception {
		ApplicantBO bo=null;
		 List<ApplicantBO>  count=new ArrayList();
		
		//create BO class obj
		bo=new ApplicantBO();
		bo.setFirstName(dto.getFirstName());
		bo.setLastName(dto.getLastName());
		bo.setCourse(dto.getCourse());
		bo.setEmailID(dto.getEmailID());
		bo.setPhNO(dto.getPhNO());
		bo.setDob(dto.getDob());
		//Use DAO
		//System.out.println("2ND..............");
		count=dao.insertApplicantDetails(bo);
		System.out.println("Data Inserted Successfully");
		run();
		System.out.println("Wait, Admin is processing ur Request");
//		Iterator it=count.iterator();
//		while(it.hasNext()) {
//			
//			System.out.println(it.next());
//		}
		
		count=ac.checkApplicantData(count);
		//System.out.println(count.isEmpty()+" @@@@@@@@@@@@");
		if(count.isEmpty()) {
			System.out.println("5th...............");
			return "Details Not Inserted";
		}
		else {
		//System.out.println("Your data is approved "+new Date());
		 return "Welcome to Virtusa College!";
		}
	}//generate()

	@Override
	public void run() {
		
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	}

}//class
