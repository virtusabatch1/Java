package com.nt.service;

import com.nt.dto.ApplicantDTO;

public interface ApplicantService{
	public String generateApplicantDetails(ApplicantDTO dto) throws Exception;
}