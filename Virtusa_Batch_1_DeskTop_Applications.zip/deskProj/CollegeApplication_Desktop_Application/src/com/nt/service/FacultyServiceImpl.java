package com.nt.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.nt.bo.FacultyBO;
import com.nt.bo.StudentBO;
import com.nt.dao.FacultyDAO;
import com.nt.dao.FacultyDAOImpl;
import com.nt.dto.FacultyDTO;
import com.nt.dto.StudentDTO;

public class FacultyServiceImpl implements FacultyService {
private FacultyDAO dao;
	
	public FacultyServiceImpl() {
		dao=new FacultyDAOImpl();
	}
	@Override
	public String generateFacultyDetails(FacultyDTO dto) throws Exception {
		FacultyBO bo=null;
		List<FacultyBO>  count=new ArrayList();
		
		bo=new FacultyBO();
		bo.setfID(dto.getfID());
		bo.setName(dto.getName());
		bo.setAge(dto.getAge());
		bo.setAddress(dto.getAddress());
		
		//use Dao
		count=dao.insertFacultyDetails(bo);
		Iterator it=count.iterator();
		while(it.hasNext()) {
			System.out.println("3rd............");
			System.out.println(it.next());
		}
		
		if(count.isEmpty()) {
			System.out.println("5th...............");
			return "Faculty Details Not Inserted";
		}
		else {
		return "Faculty Details Inserted Successfully";
		}
	}//generate
	
	public  List<FacultyDTO> ProcessFacultyDetails() throws Exception {
		List<FacultyDTO> listdto=new ArrayList<>();
		List<FacultyBO>  count=null;
		//create DTO class obj
		count=dao.getFacultyDetails();
		FacultyBO bo=count.get(0);
		FacultyDTO  dto=new FacultyDTO();
		dto.setfID(bo.getfID());
		dto.setName(bo.getName());
		dto.setAge(bo.getAge());
		dto.setAddress(bo.getAddress());
		
		
		listdto.add(dto);
		
		
		//System.out.println(count.get(0).getAddress());
		return listdto;
		
	}

}
