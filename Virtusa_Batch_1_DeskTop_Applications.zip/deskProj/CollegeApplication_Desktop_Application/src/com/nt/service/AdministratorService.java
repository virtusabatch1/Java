package com.nt.service;

import java.util.List;

import com.nt.dto.AdministratorDTO;


public interface AdministratorService {
	public String generateAdministratorDetails(AdministratorDTO dto) throws Exception;
	public  List<AdministratorDTO> ProcessAdministratorDetails() throws Exception;
}
