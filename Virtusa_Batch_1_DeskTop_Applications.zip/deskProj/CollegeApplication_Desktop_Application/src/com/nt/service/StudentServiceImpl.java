package com.nt.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.nt.bo.StudentBO;
import com.nt.dao.StudentDAO;
import com.nt.dao.StudentDAOImpl;
import com.nt.dto.StudentDTO;

public class StudentServiceImpl implements StudentService {
	private  StudentDAO dao;
	
	public StudentServiceImpl() {
		dao=new StudentDAOImpl();
	}

	@Override
	public String generateStudentDetails(StudentDTO dto) throws Exception {
		StudentBO bo=null;
		
		List<StudentBO>  count=new ArrayList();
		//create BO class obj
				bo=new StudentBO();
				bo.setSno(dto.getSno());
				bo.setName(dto.getName());
				bo.setAge(dto.getAge());
				bo.setAddress(dto.getAddress());
				
				//use Dao
				count=dao.insertStudentDetails(bo);
				Iterator it=count.iterator();
				while(it.hasNext()) {
					//System.out.println("3rd............");
					System.out.println(it.next());
				}
				
				if(count.isEmpty()) {
					//System.out.println("5th...............");
					return "Student Details Not Inserted";
				}
				else {
				return "Student Details Inserted Successfully";
				}
				
		
	}//method
	
	public  List<StudentDTO> ProcessStudentDetails() throws Exception {
		List<StudentDTO> listdto=new ArrayList<>();
		List<StudentBO>  count=null;
		//create DTO class obj
		count=dao.getStudentDetails();
		StudentBO bo=count.get(0);
		StudentDTO  dto=new StudentDTO();
		dto.setSno(bo.getSno());
		dto.setName(bo.getName());
		dto.setAge(bo.getAge());
		dto.setAddress(bo.getAddress());
		
		
		listdto.add(dto);
		
		
		//System.out.println(count.get(0).getAddress());
		return listdto;
		
	}

}//class
