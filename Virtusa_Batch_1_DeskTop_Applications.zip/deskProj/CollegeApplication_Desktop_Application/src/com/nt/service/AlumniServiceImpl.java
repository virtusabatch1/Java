package com.nt.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.nt.bo.AlumniBO;
import com.nt.bo.StudentBO;
import com.nt.dao.AlumniDAO;
import com.nt.dao.AlumniDAOImpl;
import com.nt.dto.AlumniDTO;
import com.nt.dto.StudentDTO;

public class AlumniServiceImpl implements AlumniService {
     private AlumniDAO dao;
     public AlumniServiceImpl() {
		dao=new AlumniDAOImpl();
	}
	@Override
	public String generateAlumniDetails(AlumniDTO dto) throws Exception {
		 AlumniBO bo=null;
		 List<AlumniBO>  count=new ArrayList();
	       //create BO class obj
	         bo=new AlumniBO();		
	         bo.setAlumID(dto.getAlumID());
	         bo.setAlumName(dto.getAlumName());
	         bo.setYop(dto.getYop());
	         
	       //Use DAO
	         count=dao.insertAlumniDetails(bo);
	         Iterator it=count.iterator();
	         while(it.hasNext()) {
	 			
	 			System.out.println(it.next());
	 		}
	         if(count.isEmpty()) {
	 			System.out.println("5th...............");
	 			return "Alumni Details Not Inserted";
	 		}
	 		else {
	 		return "Alumni Details Inserted Successfully";
	 		}
	}//method
	
	public  List<AlumniDTO> ProcessAlumniDetails() throws Exception {
		List<AlumniDTO> listdto=new ArrayList<>();
		List<AlumniBO>  count=null;
		//create DTO class obj
		count=dao.getAlumniDetails();
		AlumniBO bo=count.get(0);
		AlumniDTO  dto=new AlumniDTO();
		dto.setAlumID(bo.getAlumID());
		dto.setAlumName(bo.getAlumName());
		dto.setYop(bo.getYop());
		
		
		
		listdto.add(dto);
		
		
		//System.out.println(count.get(0).getAddress());
		return listdto;
		
	}

}//class
