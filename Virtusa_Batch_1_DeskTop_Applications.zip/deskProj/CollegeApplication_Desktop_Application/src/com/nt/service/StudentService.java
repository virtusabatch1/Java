package com.nt.service;

import java.util.List;

import com.nt.dto.StudentDTO;

public interface StudentService {
	public String generateStudentDetails(StudentDTO dto) throws Exception;

	public List<StudentDTO> ProcessStudentDetails()throws Exception;
}
