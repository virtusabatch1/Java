package com.nt.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.nt.bo.AdministratorBO;
import com.nt.bo.StudentBO;
import com.nt.dao.AdministratorDAO;
import com.nt.dao.AdministratorDAOImpl;
import com.nt.dto.AdministratorDTO;
import com.nt.dto.StudentDTO;

public class AdministratorServiceImpl implements AdministratorService {
     private AdministratorDAO dao;
     public AdministratorServiceImpl() {
		dao=new AdministratorDAOImpl();
	}
	@Override
	public String generateAdministratorDetails(AdministratorDTO dto) throws Exception{
		AdministratorBO bo=null;
		 List<AdministratorBO>  count=new ArrayList();
		//create BO class obj
		 bo=new AdministratorBO();
		 bo.setAdminID(dto.getAdminID());
		 bo.setAdminName(dto.getAdminName());
		 
		//Use DAO
		 count=dao.insertAdministratorDetails(bo);
		 Iterator it=count.iterator();
			while(it.hasNext()) {
				//System.out.println("3rd............");
				System.out.println(it.next());
			}
			
			if(count.isEmpty()) {
				
				return "Admin Details Not Inserted";
			}
			else {
			return "Admin Details Inserted Successfully";
			}
	}//method
	
	public  List<AdministratorDTO> ProcessAdministratorDetails() throws Exception {
		List<AdministratorDTO> listdto=new ArrayList<>();
		List<AdministratorBO>  count=null;
		//create DTO class obj
		count=dao.getAdministratorDetails();
		AdministratorBO bo=count.get(0);
		AdministratorDTO  dto=new AdministratorDTO();
		dto.setAdminID(bo.getAdminID());
		dto.setAdminName(bo.getAdminName());
		
		
		
		listdto.add(dto);
		
		
		//System.out.println(count.get(0).getAddress());
		return listdto;
		
	}

}//class
